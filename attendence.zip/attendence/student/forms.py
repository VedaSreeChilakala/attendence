from django.contrib.auth.models import User
from .models import ClassStudent, UserProfile, Department, Course, Student, Class
from django import forms
from .models import *
class SaveDepartment(forms.ModelForm):
    name = forms.CharField(max_length=250,help_text = "Course Name Field is required.")
    description = forms.Textarea()

    class Meta:
        model= Department
        fields = ('name','description','status')
    
    def clean_name(self):
        id = self.instance.id if not self.instance == None else 0
        try:
            if id.isnumeric() and id > 0:
                 department = Department.objects.exclude(id = id).get(name = self.cleaned_data['name'])
            else:
                 department = Department.objects.get(name = self.cleaned_data['name'])
        except:
            return self.cleaned_data['name']
        raise forms.ValidationError(f'{department.name} Department Already Exists.')

class SaveCourse(forms.ModelForm):
    department = forms.IntegerField()
    name = forms.CharField(max_length=250,help_text = "Course Name Field is required.")
    description = forms.Textarea()

    class Meta:
        model= Course
        fields = ('department', 'name','description','status')

    def clean_department(self):
        department = self.cleaned_data['department']
        try:
            dept = Department.objects.get(id = department)
            return dept
        except:
            raise forms.ValidationError(f'Department value is invalid.')

    def clean_name(self):
        id = self.instance.id if not self.instance == None else 0
        try:
            if id.isnumeric() and id > 0:
                 course = Course.objects.exclude(id = id).get(name = self.cleaned_data['name'])
            else:
                 course = Course.objects.get(name = self.cleaned_data['name'])
        except:
            return self.cleaned_data['name']
        raise forms.ValidationError(f'{course.name} course Already Exists.')

class SaveClass(forms.ModelForm):
    assigned_faculty = forms.IntegerField()
    school_year = forms.CharField(max_length=250,help_text = "School Year Field is required.")
    level = forms.CharField(max_length=250,help_text = "Level Field is required.")
    name = forms.CharField(max_length=250,help_text = "Class Name Field is required.")

    class Meta:
        model= Class
        fields = ('assigned_faculty', 'school_year','level','name')

    
class SaveStudent(forms.ModelForm):
    course = forms.IntegerField()

    class Meta:
        model = Student
        fields = ('student_code','first_name','middle_name','last_name','gender','dob','course','contact')
    
    def clean_student_code(self):
        code = self.cleaned_data['student_code']
        try:
            if not self.instance.id is None:
                student = Student.objects.exclude(id = self.instance.id).get(student_code = code)
            else:
                student = Student.objects.get(student_code = code)
        except:
            return code
        raise forms.ValidationError(f"Student Code {code} already exists.")

    def clean_course(self):
        cid = self.cleaned_data['course']
        try:
            course = Course.objects.get(id = cid)
            return course
        except:
            raise forms.ValidationError("Invalid Course Value")

class SaveClassStudent(forms.ModelForm):
    classIns = forms.IntegerField()
    student = forms.IntegerField()

    class Meta:
        model = ClassStudent
        fields = ('classIns','student')

    def clean_classIns(self):
        cid = self.cleaned_data['classIns']
        try:
            classIns = Class.objects.get(id = cid)
            return classIns
        except:
            raise forms.ValidationError("Class ID is Invalid.")
    
    def clean_student(self):
        student_id = self.cleaned_data['student']
        _class = Class.objects.get(id = self.data.get('classIns'))
        student = Student.objects.get(id = student_id)
        try:
            cs = ClassStudent.objects.get(classIns = _class, student = student)
            if len(cs) > 0:
                raise forms.ValidationError(f"Student already exists in the Class List.")
        except:
            return student
       