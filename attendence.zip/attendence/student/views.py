from django.shortcuts import render
from django.contrib.auth.models import User
from .models import *
from .forms import *

from django.contrib.auth import authenticate, login, logout

def lob(request):
    if request.method == 'POST':
        user = request.POST.get("username")
        passw = request.POST.get("password")
        userObj=User.objects.get(username=user)
        if userObj is not None:
            us=authenticate(request,username=user,password=passw)
            if us is not None:
                login(request,us)
            else:
                    return HttpResponse("Authentication failed")
        else:
            return HttpResponse("No user found")
    else:
        return render(request,"login.html",context={})
    #return HttpResponse("printed on Console, please Check!!")
deparment_list = Department.objects.exclude(status = 2).all()

context = {
    'page_title' : 'Simple Blog Site',
    'deparment_list' : deparment_list,
    'deparment_list_limited' : deparment_list[:3]
}
def home(request):
    context['page_title'] = 'Home'
    departments = Department.objects.count()
    courses = Course.objects.count()
    #faculty = UserProfile.objects.filter(user_type = 2).count()
    if request.user.profile.user_type == 1:
        students = Student.objects.count()
        classes = Class.objects.count()
    else:
        classes = Class.objects.filter(assigned_faculty = request.user.profile).count()
        students = ClassStudent.objects.filter(classIns__in = Class.objects.filter(assigned_faculty = request.user.profile).values_list('id')).count()
    context['departments'] = departments
    context['courses'] = courses
    #context['faculty'] = faculty
    context['students'] = students
    context['classes'] = classes

    # context['posts'] = posts
    return render(request, 'home.html',context)



def department(request):
    departments = Department.objects.all()
    context['page_title'] = "Department Management"
    context['departments'] = departments
    return render(request, 'department_mgt.html',context)

def manage_department(request,pk=None):
    # department = department.objects.all()
    if pk == None:
        department = {}
    elif pk > 0:
        department = Department.objects.filter(id=pk).first()
    else:
        department = {}
    context['page_title'] = "Manage Department"
    context['department'] = department

    return render(request, 'manage_department.html',context)


def save_department(request):
    resp = { 'status':'failed' , 'msg' : '' }
    if request.method == 'POST':
        department = None
        print(not request.POST['id'] == '')
        if not request.POST['id'] == '':
            department = Department.objects.filter(id=request.POST['id']).first()
        if not department == None:
            form = SaveDepartment(request.POST,instance = department)
        else:
            form = SaveDepartment(request.POST)
    if form.is_valid():
        form.save()
        resp['status'] = 'success'
        messages.success(request, 'Department has been saved successfully')
    else:
        for field in form:
            for error in field.errors:
                resp['msg'] += str(error + '<br>')
        if not department == None:
            form = SaveDepartment(instance = department)
       
    return HttpResponse("successfully")

def delete_department(request):
    resp={'status' : 'failed', 'msg':''}
    if request.method == 'POST':
        id = request.POST['id']
        try:
            department = Department.objects.filter(id = id).first()
            department.delete()
            resp['status'] = 'success'
            messages.success(request,'Department has been deleted successfully.')
        except Exception as e:
            raise print(e)
    return HttpResponse("successfully")


#Course
def course(request):
    courses = Course.objects.all()
    context['page_title'] = "Course Management"
    context['courses'] = courses
    return render(request, 'course_mgt.html',context)

def manage_course(request,pk=None):
    # course = course.objects.all()
    if pk == None:
        course = {}
        department = Department.objects.filter(status=1).all()
    elif pk > 0:
        course = Course.objects.filter(id=pk).first()
        department = Department.objects.filter(Q(status=1) or Q(id = course.id)).all()
    else:
        department = Department.objects.filter(status=1).all()
        course = {}
    context['page_title'] = "Manage Course"
    context['departments'] = department
    context['course'] = course

    return render(request, 'manage_course.html',context)

def save_course(request):
    resp = { 'status':'failed' , 'msg' : '' }
    if request.method == 'POST':
        course = None
        print(not request.POST['id'] == '')
        if not request.POST['id'] == '':
            course = Course.objects.filter(id=request.POST['id']).first()
        if not course == None:
            form = SaveCourse(request.POST,instance = course)
        else:
            form = SaveCourse(request.POST)
    if form.is_valid():
        form.save()
        resp['status'] = 'success'
        messages.success(request, 'Course has been saved successfully')
    else:
        for field in form:
            for error in field.errors:
                resp['msg'] += str(error + '<br>')
        if not course == None:
            form = SaveCourse(instance = course)
       
    return HttpResponse("successfully")

def delete_course(request):
    resp={'status' : 'failed', 'msg':''}
    if request.method == 'POST':
        id = request.POST['id']
        try:
            course = Course.objects.filter(id = id).first()
            course.delete()
            resp['status'] = 'success'
            messages.success(request,'Course has been deleted successfully.')
        except Exception as e:
            raise print(e)
    return HttpResponse("successfully")


def classPage(request):
    if request.user.profile.user_type == 1:
        classes = Class.objects.all()
    else:
        classes = Class.objects.filter(assigned_faculty = request.user.profile).all()

    context['page_title'] = "Class Management"
    context['classes'] = classes
    return render(request, 'class_mgt.html',context)

def manage_class(request,pk=None):
    faculty = UserProfile.objects.filter(user_type= 2).all()
    if pk == None:
        _class = {}
    elif pk > 0:
        _class = Class.objects.filter(id=pk).first()
    else:
        _class = {}
    context['page_title'] = "Manage Class"
    context['faculties'] = faculty
    context['class'] = _class

    return render(request, 'manage_class.html',context)

def view_class(request, pk= None):
    if pk is None:
        return redirect('home-page')
    else:
        _class = Class.objects.filter(id=pk).first()
        students = ClassStudent.objects.filter(classIns = _class).all()
        context['class'] = _class
        context['students'] = students
        context['page_title'] = "Class Information"
    return render(request, 'class_details.html',context)


def save_class(request):
    resp = { 'status':'failed' , 'msg' : '' }
    if request.method == 'POST':
        _class = None
        print(not request.POST['id'] == '')
        if not request.POST['id'] == '':
            _class = Class.objects.filter(id=request.POST['id']).first()
        if not _class == None:
            form = SaveClass(request.POST,instance = _class)
        else:
            form = SaveClass(request.POST)
    if form.is_valid():
        form.save()
        resp['status'] = 'success'
        messages.success(request, 'Class has been saved successfully')
    else:
        for field in form:
            for error in field.errors:
                resp['msg'] += str(error + '<br>')
        if not _class == None:
            form = SaveClass(instance = _class)
       
    return HttpResponse("successfully")

def delete_class(request):
    resp={'status' : 'failed', 'msg':''}
    if request.method == 'POST':
        id = request.POST['id']
        try:
            _class = Class.objects.filter(id = id).first()
            _class.delete()
            resp['status'] = 'success'
            messages.success(request,'Class has been deleted successfully.')
        except Exception as e:
            raise print(e)
    return HttpResponse("successfully.")

def delete_student(request):
    resp={'status' : 'failed', 'msg':''}
    if request.method == 'POST':
        id = request.POST['id']
        try:
            student = Student.objects.filter(id = id).first()
            student.delete()
            resp['status'] = 'success'
            messages.success(request,'Student Details has been deleted successfully.')
        except Exception as e:
            raise print(e)
    return HttpResponse("successfully")

def attendance_class(request):
    if request.user.profile.user_type == 1:
        classes = Class.objects.all()
    else:
        classes = Class.objects.filter(assigned_faculty = request.user.profile).all()
    context['page_title'] = "Attendance Management"
    context['classes'] = classes
    return render(request, 'attendance_class.html',context)

def attendance(request,classPK = None, date=None):
    _class = Class.objects.get(id = classPK)
    students = Student.objects.filter(id__in = ClassStudent.objects.filter(classIns = _class).values_list('student')).all()
    context['page_title'] = "Attendance Management"
    context['class'] = _class
    context['date'] = date
    att_data = {}
    for student in students:
        att_data[student.id] = {}
        att_data[student.id]['data'] = student
    if not date is None:
        date = datetime.strptime(date, '%Y-%m-%d')
        year = date.strftime('%Y')
        month = date.strftime('%m')
        day = date.strftime('%d')
        attendance = Attendance.objects.filter(attendance_date__year = year, attendance_date__month = month, attendance_date__day = day, classIns = _class).all()
        for att in attendance:
            att_data[att.student.pk]['type'] = att.type
    print(list(att_data.values()))
    context['att_data'] = list(att_data.values())
    context['students'] = students

    return render(request, 'attendance_mgt.html',context)

def save_attendance(request):
    resp = {'status' : 'failed', 'msg':''}
    if request.method == 'POST':
        post = request.POST
        date = datetime.strptime(post['attendance_date'], '%Y-%m-%d')
        year = date.strftime('%Y')
        month = date.strftime('%m')
        day = date.strftime('%d')
        _class = Class.objects.get(id=post['classIns'])
        Attendance.objects.filter(attendance_date__year = year, attendance_date__month = month, attendance_date__day = day,classIns = _class).delete()
        for student in post.getlist('student[]'):
            type = post['type['+student+']']
            studInstance = Student.objects.get(id = student)
            att = Attendance(student=studInstance,type = type,classIns = _class,attendance_date=post['attendance_date']).save()
        resp['status'] = 'success'
        messages.success(request,"Attendance has been saved successfully.")
    return HttpResponse("successfully")